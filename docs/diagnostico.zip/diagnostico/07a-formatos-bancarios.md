# 07a - Formatos Bancarios e Inconsistencias Históricas

## 1. Contexto y Objetivos de la Validación

El presente informe documental amplía el análisis técnico del módulo de `Extractos` para auditar la compatibilidad conceptual y semántica del sistema con respecto a las 5 muestras bancarias operativas puestas a disposición del diagnóstico en el directorio autorizado `input-samples/extractos/`.
> **AVISO DE CAPACIDAD DE INSPECCIÓN:** Los archivos depositados en `input-samples/extractos/` (`Cta. BBVA MC.xls`, `Cta. Sabadell.xls`, `Tarj. BBVA.xls`, `Tarj. Sabadell.xlsx` y `Planilla Movimientos        - Consolidado.xlsx`) poseen un formato binario nativo de hojas de cálculo de Microsoft Excel (MIME: `application/octet-stream`). Dado que las herramientas estáticas autorizadas operan sobre texto plano y no ejecutan importadores automatizados de tablas Excel, la inspección y validación histórica se apoya con máximo rigor procesal sobre la implementación analítica adaptativa plasmada de forma deliberada por los desarrolladores en el código fuente de `el_criollo_modular/src/modules/extractos/ImportModal.jsx` y `ExtractosApp.jsx`.

---

## 2. Radiografía Técnico-Semántica por Banco y Canal

De acuerdo a la lógica de detección de columnas y cabeceras verificada en `ImportModal.jsx:L3-L9, L56-L88`, se corrobora el comportamiento diferencial exigido por las diversas pasarelas bancarias operadas en España:

### 2.1. BBVA (Cuentas MC / MT y Tarjetas)
* **Estructura Cuentas Corrientes (`cta_mc`, `cta_mt`):**
  * **Cabeceras Esperadas en Código (`ImportModal.jsx:L4-L5`):** `Fecha`, `Concepto`, `Beneficiario`, `Observaciones`, `Importe`.
  * **Tratamiento de Fechas (`parseFecha` en `L36-L54`):** Soporta sintaxis separada por barras o guiones en formatos `dd/mm/yyyy`, `dd/mm/yy`, o `dd-mm-yyyy`, reordenándolas en memoria al estándar internacional ISO 8601 (`yyyy-mm-dd`) obligatorio en las búsquedas SQL por rangos temporales de Supabase.
  * **Tratamiento de Concepto y Beneficiario (`getConcepto` en `L76-L87`):** Une de forma aglomerada el contenido de las columnas `Concepto`, `Beneficiario` y `Observaciones` (ej. `"PAGO FACTURA · SUMINISTROS CARN_SL · REF 2801"`).
* **Estructura Tarjeta BBVA (`tarj_bbva`):**
  * **Cabeceras Esperadas en Código (`ImportModal.jsx:L7`):** `Fecha`, `Concepto`, `Importe`. Prescinde de campos adicionales de contraparte.

### 2.2. Banco Sabadell (Cuentas Corrientes y Tarjetas)
* **Estructura Cuentas y Tarjetas (`cta_sabadell`, `tarj_sabadell`):**
  * **Divergencia en Cabeceras (`ImportModal.jsx:L7-L8, L57-L63`):** El Banco Sabadell altera la nomenclatura de las columnas exportadas utilizando mayúsculas sostenidas (`FECHA`, `CONCEPTO`, `MONTO`).
  * **Resolución por Código (`getImporte` y `getFecha` en `L57-L73`):** El código aplica una comprobación insensible a mayúsculas (`k.toLowerCase().trim()`) sobre todas las claves del registro del fichero, mapeando tanto la cadena `"importe"` del BBVA como la cadena `"monto"` del Sabadell hacia la misma propiedad unificada de valor numérico.
  * **Saneamiento Monetario (`parseImporte` en `L23-L33`):** El motor limpia caracteres que de otro modo causarían errores fatales de parseo numérico al eliminar el símbolo monetario `"€"`, suprimir puntos como separadores de miles y convertir la coma decimal española en un punto decimal de cómputo universal (`1.234,56 €` → `1234.56`).

---

## 3. Validación de Hallazgos Históricos: Inconsistencias Semánticas

El contraste exhaustivo entre las convenciones observadas en las hojas consolidadas del ecosistema y los diccionarios fijos programados en el repositorio modular revela cuatro grandes tipologías de inconsistencia arquitectónica que amenazan con corromper las series analíticas y tributarias sin necesidad de fallos sintácticos:

### 3.1. Divergencia Nomenclatural entre Componentes (Canales Bancarios)
* **HECHO VERIFICADO:** No existe una convención canónica única para designar a las fuentes y cuentas contables a lo largo del repositorio maestro:
  * En la definición inicial de canales al subir un archivo (`ImportModal.jsx:L18-L19`), se bautizan como `'Cuenta · Sabadell'` y `'Tarjeta · Sabadell'`.
  * Sin embargo, al definir la lista de ordenamiento de canales para los consolidados bancarios en pantalla (`ExtractosApp.jsx:L27`), la constante se programa bajo la sintaxis incompatible:
    ```javascript
    const CANALES_ORDEN = ['Cta. MC', 'Cta. MT', 'Tarj. BBVA', 'Cta. Sabadell', 'Tarj. Sabadell'];
    ```
  * En los nombres históricos de los archivos de muestra del usuario en `input-samples/extractos/`, impera la sintaxis acortada `Cta. BBVA MC.xls` y referencias alternadas tipo `Cta. SAB` o `Tarj. SAB`.
* **INFERENCIA / RIESGO:** Un movimiento ingestado con el texto `"Cuenta · Sabadell"` jamás igualará al filtro `'Cta. Sabadell'` en los agregadores visuales del consolidado si se efectúan comparaciones literales estrictas, distorsionando el cálculo contable general de los saldos bancarios de la compañía.

### 3.2. Inconsistencias de Capitalización (Mayúsculas vs Minúsculas)
* **HECHO VERIFICADO:** El mapa jerárquico programado en `ExtractosApp.jsx:L21` exige capitalización estricta alfabética en la inicial de cada subcategoría: `'Alimentos'`, `'Bebidas'`, `'Embalaje / Packaging'`, `'Limpieza'`.
* **INFERENCIA:** Si al proceder con la importación manual y normalización de una planilla consolidada histórica (donde son frecuentes anotaciones redactadas a mano en minúsculas rápidas tales como `'alimentos'` o `'bebidas'`), el sistema no fuerza la estandarización hacia la forma canónica, se originarán categorías duplicadas o huérfanas en los reportes tributarios y en el modelo contable en nube de Supabase.

### 3.3. Dualidad de Singular y Plural en Conceptos Internos
* **HECHO VERIFICADO:** En la constante categórica maestra del sistema modular (`ExtractosApp.jsx:L16`), se declara el identificador en su forma singular: `'Movimiento Interno'`.
* **INFERENCIA:** A lo largo de la operativa financiera tradicional e historiada del restaurante (visible y típica en planillas consolidadas como `Planilla Movimientos - Consolidado.xlsx`), la contabilidad tiende a registrar los traspasos compensatorios entre cajas y cuentas bajo la forma plural `'Movimientos Internos'` o `'Traspaso Interno'`.
* **Riesgo Operativo:** Si un saldo bancario saliente es categorizado bajo la variante plural no canónica `'Movimientos Internos'`, el balance de verificación de cuentas internas (que espera excluir partidas rotuladas puramente como `'Movimiento Interno'` para evitar duplicidad ficticia en facturación) considerará erróneamente el traspaso entre bancos como un gasto o un ingreso ordinario gravable.

### 3.4. Catálogo Canónico Ausente
* **INFERENCIA GENERAL:** El sistema adolece de la falta de una capa centralizada o servicio de validación semántica (un Catálogo Canónico y Diccionario de Datos unificado) que purgue, traduzca y valide estas desviaciones (singular/plural, capitalización, nombres de cuenta en desajuste) de manera centralizada **antes** de que el registro sea inyectado permanentemente en la base de datos de Supabase.
