# 04 - Auditoría de Bases de Datos y Modelaje

## 1. Alcance e Inspección Estática de Volcados

De acuerdo con las instrucciones de seguridad, se ha realizado un análisis 100% estático de los tres volcados MySQL autorizados ubicados en `database-dumps/`, así como la reconstrucción deductiva de los esquemas PostgreSQL esperados en Supabase desde el código cliente, sin ejecutar sentencias SQL ni importar datos. Toda credencial y dato personal ha sido debidamente redactada.

---

## 2. Inspección de Volcados MySQL (Legacy & TPV)

### 2.1. `athcomar_inventario_el_criollo.sql`
* **HECHO VERIFICADO:** Contiene 7 tablas operativas: `almacenes`, `formatos`, `movimientos`, `planificacion`, `presentaciones`, `productos`, y `usuarios` (L30-L210).
* **HECHO VERIFICADO (Ausencia de Claves Foráneas / FK):**
  * La tabla `movimientos` (`L71-L81`), columna vertebral del control de inventario, registra los campos `almacen`, `producto` y `formato` como columnas de tipo `varchar(50)` y `varchar(100)`, en lugar de utilizar identificadores numéricos referenciados hacia `almacenes(id)`, `productos(id)` o `formatos(id)`.
  * **Riesgo:** Si un usuario o administrador altera el nombre de un producto (ej. de "Tinga" a "Tinga de Pollo"), se rompe el vínculo referencial del historial de movimientos y el cálculo del balance contable fracasa.
* **HECHO VERIFICADO (Exposición de Hashes y Datos Personales):**
  * En la tabla `usuarios` (`L215-L220`), conviven registros de personal con sus correos reales de Gmail y corporativos, contraseñas cifradas en formato bcrypt (`$2y$10$...`) y enlaces públicas a avatares cargados al dominio `vegendigital.com/sistemas/inventario/uploads/...`.
* **HECHO VERIFICADO:** No existe columna `tenant_id` ni estructura multi-empresa. Los almacenes (ej. 'Vallecas', 'Palencia') están tipificados en duro para una sola entidad legal.

### 2.2. `athcomar_comprasWS.sql` (y esquema en `pedidos/backend/database.sql`)
* **HECHO VERIFICADO:** Define las tablas `users`, `providers`, `products`, `orders`, `order_items`, y `list_options` (`database.sql:L9-L84`).
* **HECHO VERIFICADO:** En este modelo sí existen claves foráneas relacionales explícitas en el DDL:
  * `products.provider_id` referencia a `providers(id) ON DELETE SET NULL` (`database.sql:L52`).
  * `order_items.order_id` referencia a `orders(id) ON DELETE CASCADE` (`database.sql:L74`).
* **HECHO VERIFICADO (Divergencia con Código):** En la tabla `orders` (`L56-L64`), se guarda el texto literal `provider_name` y `user_name` en vez de los identificadores `provider_id` o `user_id`. Esto inyecta vulnerabilidad ante duplicidades o reubicaciones de proveedores en el histórico.

### 2.3. `athcomar_vegen_Last_API.sql` (Volcado de 2.9 MB)
* **HECHO VERIFICADO:** Sostiene el esquema analítico para el motor Node.js/TPV. Contiene tablas relacionales tales como `ingredients` (`L30-L36`), `product_bcg_history` (`L53-L59`), `users`, `staff`, `staff_shifts`, `transactions`, y `product_sales` (evidencia respaldada conjuntamente por las sentencias DML en `last_API/backend/src/server.js:L123-L285`).
* **HECHO VERIFICADO:** En lugar de identificadores auto-incrementales en `user_id`, utiliza columnas `varchar(255)` para persistir el UID criptográfico proveniente de Firebase Auth (ej. `'yWyEEbBSKCggJFX...'` visible en las inserciones DML `L43-L45` y `L66-L150`).
* **HECHO VERIFICADO:** Modela el historial de posicionamiento estratégico gastronómico en `product_bcg_history`, registrando el estado en la matriz BCG (`STAR`, `PLOW`, `PUZZLE`, `DOG`) vinculado por nombre del producto y el UID de Firebase.

---

## 3. Reconstrucción del Esquema PostgreSQL en Supabase

A falta de un archivo de volcado SQL directo para Supabase, se reconstruye con precisión y rigor procesal el esquema remoto en función de las sentencias JS constatadas en `el_criollo_modular`:

| Tabla Supabase | Columnas Inferidas desde Código | Estado | Riesgos Auditados y Observaciones |
| :--- | :--- | :--- | :--- |
| `extractos` | `id`, `fecha`, `importe`, `concepto`, `canal`, `categoria`, `subcategoria`, `proveedor`, `notas`, `created_at` (`ExtractosApp.jsx:L87-L91`, `ImportModal.jsx:L94-L103`). | Verificada (DML) | **Crítico:** Carece de `tenant_id` o `user_id`. Al hacer un `select('*')` en cliente sin políticas RLS habilitadas, cualquier inquilino descarga la contabilidad del resto de restaurantes. |
| `produccion_registros` | `id`, `producto`, `cantidad`, `unidad`, `merma`, `turno`, `responsable`, `responsable_id`, `notas`, `created_at` (`ProduccionApp.jsx:L76-L81`). | Verificada (DML) | Almacena redundancia semántica (`responsable` como string y `responsable_id` como UUID/ID). Sin clave de inquilino ni aislamiento SaaS. |
| `empleados` | `id`, `nombre`, `apellidos`, `nif`, `cargo`, `created_at` (`HorariosApp.jsx`, `ProduccionApp.jsx:L316`). | Verificada (DML) | Tabla independiente sin relación vinculada de clave foránea con usuarios Firebase ni esquema multi-tenant. |
| `fichajes` / `incidencias` | `id`, `empleado_id`, `entrada`, `salida`, `tipo_turno`, `created_at` (`HorariosApp.jsx`). | Verificada (DML) | Soporte operacional para registro horario en España, pero vulnerable a consultas cruzadas si las políticas RLS remanecen inactivas en PostgreSQL. |

---

## 4. Evaluación de Preparación para SaaS Multi-Tenant

* **INFERENCIA:** La preparación global del modelo de datos para un modelo SaaS Multi-Tenant es **NULA / 0%**.
* **RECOMENDACIÓN TÉCNICA:** Será imprescindible ejecutar una migración de esquema en Supabase que:
  1. Inyecte la columna obligatoria `tenant_id (UUID NOT NULL REFERENCES tenants(id))` en cada tabla operativa (`extractos`, `empleados`, `produccion_registros`).
  2. Sustituya los enlaces nominales (strings en proveedores y almacenes) por verdaderas relaciones SQL FK (`FOREIGN KEY (almacen_id) REFERENCES almacenes(id)`).
