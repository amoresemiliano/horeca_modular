# 12 - Hoja de Ruta de Implementación (Roadmap)

## 1. Filosofía de Despliegue y Cronograma Modular

De acuerdo con las premisas operativas de la **Metodología Vegen Digital SL**, el presente cronograma rechaza de plano las reingenierías completas en bloque que amenacen con perturbar las operaciones del día a día (Regla de Oro de Continuidad Operacional). En su lugar, se estructura un plan evolutivo escalonado en tres fases operativas correladas que aseguran valor continuo para Taquería El Criollo al tiempo que sientan los cimientos inamovibles para una posterior comercialización en modelo SaaS Multi-Tenant en España.

---

## 2. Planificacion de Sprints y Fases de Remediación

### Fase 1 (Sprints 1 - 2): Estabilización, Blindaje y Saneamiento Técnico
**Objetivo Prioritorio:** Detener la acumulación de deuda técnica de alto riesgo, tapar grietas críticas de seguridad cibernética y construir el arnés básico de pruebas en el entorno de desarrollo actual.

* **Sprint 1 (Semanas 1 - 2): Saneamiento de Seguridad y SSoT Inicial**
  * [x] **Tarea 1.1:** Rotar de manera perentoria todas las contraseñas reales e identificadores en los motores MySQL alojados en cPanel (BlueHost: `athcomar_comprasWS`) y Node (`last_API`).
  * [x] **Tarea 1.2:** Ejecutar una purga en el historial Git (`git filter-repo` o equivalente) del repositorio `orden_compra_WS` para eliminar rastros de `db_connect.php` con secretos y suprimir del índice de Git el fichero `.env` en `last_API`.
  * [x] **Tarea 1.3:** Incorporar la librería ligera de testeo **Vitest** dentro del ecosistema Vite 6 de `el_criollo_modular`, configurando el arnés básico con pruebas unitarias sobre los métodos analíticos monetarios e importadores actuales.
  * [x] **Tarea 1.4:** Erradicar definitivamente la dependencia de `localStorage('vdc_permisos')` y `loggedUser` para autorizaciones y roles, delegando todo control de acceso a tokens firmados criptográficamente (JWT) en el backend de Firebase/Supabase.

* **Sprint 2 (Semanas 3 - 4): Universalización de Extractos Bancarios y Cierre de Webhooks**
  * [x] **Tarea 2.1:** Extender el componente `ImportModal.jsx` incorporando adaptadores de lectura para ficheros binarios nativos Excel (`.xls` y `.xlsx`), erradicando la limitación cautiva de PapaParse con archivos exclusivamente de texto `.csv`.
  * [x] **Tarea 2.2:** Reingenierizar el algoritmo de deduplicación contable sustituyendo el discriminatorio ingenuo en memoria (`fecha+importe+concepto+canal`) por un cálculo hash SHA-256 inyectado mediante restricción de unicidad relacional (`UNIQUE INDEX`) en PostgreSQL.
  * [x] **Tarea 2.3:** Proteger y blindar el endpoint `/webhook/lastapp` del servidor en puerto 3001, implementando verificación obligatoria de firmas criptográficas HMAC, impidiendo la inyección arbitraria externa y persistiendo las ventas del TPV directamente en base de datos.

---

### Fase 2 (Sprints 3 - 5): Unificación Operacional en Supabase (Fin del Legado)
**Objetivo Prioritorio:** Apagar sin traumas contables los servidores monolíticos PHP heredados en BlueHost y acabar con las islas de datos dependientes del almacenamiento en navegadores.

* **Sprint 3 (Semanas 5 - 6): Absorción de Pedidos en la SPA Maestra**
  * [x] **Tarea 3.1:** Crear el esquema relacional para pedidos en Supabase (`proveedores`, `productos`, `ordenes`, `lineas_pedido`), integrando y vinculando el catálogo unificado de insumos contables.
  * [x] **Tarea 3.2:** Reemplazar los arrays fijos simulados (`useState`) del prototipo actual en `src/modules/pedidos/PedidosApp.jsx` por llamadas al API de Supabase, preservando y mejorando los buscadores rápidos inspirados en Tom-Select pero de forma nativa para React 19.
  * [x] **Tarea 3.3:** Trasladar la lógica del generador de enlaces formateados por WhatsApp (`wa.me`) al nuevo módulo en React, apagando de forma definitiva y segura el servidor PHP remoto heredado.

* **Sprint 4 y 5 (Semanas 7 - 10): Liberación del Almacén e Inventarios**
  * [x] **Tarea 4.1:** Retirar y reestructurar el hook `usePersistedState` que cautiva los reducers del inventario en `store.jsx`, sustituyendo los 6 depósitos de `localStorage` por consultas seguras hacia tablas relacionales conectadas en Supabase con Foreign Keys obligatorias y estrictas (`almacenes`, `productos`, `movimientos`).
  * [x] **Tarea 4.2:** Interconectar en tiempo real las mermas de almacén, consumos de recetas (`Escandallos`) y las ventas del TPV entrantes (`last_API`), consolidando la **Única Fuente de Verdad (SSoT)**.
  * [x] **Tarea 4.3:** Elaborar pruebas de integración continuas (E2E y unitarias) para verificar la precisión del cálculo contable y de stock en operaciones concurrentes de inventario y cocina.

---

### Fase 3 (Sprints 6 - 8): Arquitectura Multi-Tenant SaaS y Escalado Comercial
**Objetivo Prioritorio:** Disponer una plataforma de gestión HORECA comercializable corporativamente en el mercado de España con estricta separación criptográfica de clientes de empresa (Multi-Tenant).

* **Sprint 6 (Semanas 11 - 12): Inyección Multi-Tenant y Políticas RLS**
  * [x] **Tarea 6.1:** Ejecutar una migración estructural en Supabase PostgreSQL agregando indeclinablemente la columna `tenant_id` en todas y cada una de las tablas del sistema contable y de cocina.
  * [x] **Tarea 6.2:** Redactar, probar y promulgar en el motor SQL de Supabase políticas de seguridad a nivel de fila (**Row Level Security - RLS**) inquebrantables, restringiendo cada consulta y transacción al identificador de inquilino certificado por el token JWT emitido por la entidad proveedora de acceso (`auth.jwt() ->> 'tenant_id'`).

* **Sprint 7 y 8 (Semanas 13 - 16): Pulido de UI/UX, Automatización BI y Lanzamiento**
  * [x] **Tarea 7.1:** Reactivar e inyectar el motor de cálculos de la Matriz BCG y KPIs sin cargas manuales de CSV al módulo de Business Intelligence (`KpisApp.jsx`), utilizando Supabase Edge Functions para alimentar gráficos en tiempo real (Chart.js) orientados a maximizar la rentabilidad directiva.
  * [x] **Tarea 7.2:** Habilitar jerarquías y cuentas contables personalizables e importadoras dinámicas al plan de negocio por tenant SaaS en España, superando los menús categóricos en duro (`SUBCATEGORIAS` estáticas) auditados durante la Fase 0.
  * [x] **Tarea 7.3:** Auditoría final pre-comercial para asegurar latencia ultra-baja y experiencia de diseño sobresaliente e ininterrumpida frente al usuario comercial.
