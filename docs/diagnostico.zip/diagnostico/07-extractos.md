# 07 - Módulo Bancos y Extractos: Auditoría Estructurada

## 1. Alcance de la Auditoría Bancaria

El módulo `Bancos / Extractos` constituye el pilar analítico más sofisticado y operado de la plataforma moderna `el_criollo_modular`. En cumplimiento de la directriz de diagnóstico, no se presupone que el módulo sea impenetrable por apoyarse en tecnologías actuales como Supabase o PapaParse. Se ha procedido a examinar de manera estricta la fiabilidad del motor de ingestión de archivos y su capacidad contable para operar a nivel multi-empresa y multi-restaurante.

---

## 2. Incompatibilidad Crítica entre Código y Ficheros Bancarios

* **HECHO VERIFICADO (Límite en Código Cliente):**
  * El componente encargado de procesar la importación del banco, `el_criollo_modular/src/modules/extractos/ImportModal.jsx`, implementa su analizador léxico de archivos llamando estrictamente a la librería PapaParse (`ImportModal.jsx:L123-L139`):
    ```javascript
    Papa.parse(file, { header: true, skipEmptyLines: true, encoding: 'UTF-8', ... });
    ```
  * En la interfaz web se restringe el ingreso de ficheros mediante los filtros `accept=".csv"` (`L230`) y los mensajes informativos `"Solo archivos .csv · Formato {canal.banco}"` (`L225`).
* **HECHO VERIFICADO (Realidad de las Muestras en Workspace):**
  * En el directorio autorizado `input-samples/extractos/` del ecosistema se constata que **ninguno** de los archivos de muestra está en formato texto CSV. Los cinco libros proporcionados son ficheros Excel verdaderos (formato binario u Office Open XML):
    * `Cta. BBVA MC.xls` y `Tarj. BBVA.xls` (MIME: `application/octet-stream` u Office 97-2003 binario).
    * `Cta. Sabadell.xls` (MIME: `application/octet-stream` binario).
    * `Tarj. Sabadell.xlsx` y `Planilla Movimientos        - Consolidado.xlsx` (Libros Excel nativos comprimidos en ZIP/OOXML).
* **INFERENCIA / RIESGO OPERACIONAL INMEDIATO:**
  * Al no existir soporte para ficheros binarios `.xls` ni `.xlsx`, **cualquier operador de Taquería El Criollo que intente arrastrar los extractos descargados en su formato bancario original a la aplicación moderna sufrirá un fallo de parseo inminente** (PapaParse rechazará o interpretará texto basura ilegible ante un flujo binario).
  * **Recomendación:** Es de vital necesidad incorporar una librería puente capaz de leer archivos binarios de Excel en el navegador (tal como `xlsx` / `SheetJS` o `exceljs`), convirtiendo la primera hoja del libro de cálculo en un array o cadena CSV antes de someterla al flujo de transformación existente.

---

## 3. Vulnerabilidad en el Algoritmo de Deduplicación (False Positives)

* **HECHO VERIFICADO:** En el hook `useExtractosDB` del archivo `el_criollo_modular/src/modules/extractos/ExtractosApp.jsx:L75-L82`, la lógica encargada de evitar la inserción de registros duplicados al subir extractos ejecuta un filtro en memoria basado en un hash ingenuo constituido únicamente por la coincidencia simultánea de cuatro propiedades:
  ```javascript
  const novedades = newItems.filter(ni =>
    !db.find(x =>
      x.fecha     === ni.fecha    &&
      x.importe   === ni.importe  &&
      x.concepto  === ni.concepto &&
      x.canal     === ni.canal
    )
  );
  ```
* **ANÁLISIS DE FALSOS POSITIVOS Y PÉRDIDA DE CONTABILIDAD:**
  * En la operativa diaria de un restaurante, son enormemente habituales las compras repetidas o cobros fraccionados idénticos en un mismo día.
  * **Caso Práctico de Fallo:** Si un gerente abona por tarjeta o cuenta dos facturas independientes de 45,50 € al mismo proveedor el mismo día (ej. una reposición urgente de hielo o bebidas al por mayor a primera hora y otra segunda entrega idéntica por la noche con el concepto genérico "COMPRA EN COMERCIO" o "PAGO TPV PROVEEDOR"), **la segunda transacción válida será interpretada indebidamente por el sistema como un duplicado y se eliminará sin previo aviso al usuario**.
  * Además, el filtrado de duplicados corre exclusivamente de forma volátil contra los items cargados en el estado local `db` en la memoria del navegador (`ExtractosApp.jsx:L76`), careciendo de un índice relacional o restricción única (`UNIQUE CONSTRAINT`) real y robusto respaldada en el motor de base de datos PostgreSQL de Supabase.
* **RECOMENDACIÓN TÉCNICA (Hash de Grado Financiero):**
  * El discriminante debe ser reingenierizado para calcular un hash SHA-256 criptográfico que combine de forma indivisible: el identificador único o referencia que el banco asigna cuando exista, cuenta financiera de origen, fecha de operación real vs fecha valor, importe exacto, saldo contable resultante tras la operación (el saldo distingue indiscutiblemente la secuencia entre dos cobros idénticos), número de ocurrencia secuencial del ítem dentro del archivo diario cargado (`idx`), y el hash general de verificación del archivo importado.

---

## 4. Análisis Semántico: Proveedor, Contraparte y Estructura Jerárquica

* **HECHO VERIFICADO:** En `ImportModal.jsx:L97-L102`, al parsear cada movimiento bancario, la lógica funde las columnas `Concepto`, `Beneficiario` y `Observaciones` en una única cadena de texto plana en la propiedad `concepto` (`getConcepto(row)`), dejando deliberadamente vacío el campo `proveedor: ''`, `categoria: ''` y `subcategoria: ''`.
* **INFERENCIA (Contraparte vs Proveedor Contable):**
  * En un extracto bancario, el texto devuelto como beneficiario/emisor es la **Contraparte Bancaria** (ej. `"COMPRA TPV 009823 SUMINISTROS HOSTEL SL"`). El sistema comete un salto conceptual si se pretende usar dicho texto plano como equivalente al **Proveedor del Ecosistema** sin una tabla intermedia de resolución de nombres ("Normalización de Contrapartes").
  * Actualmente, al dejar el proveedor vacío al importar, recae en el usuario la pesadísima carga manual de categorizar y asignar el proveedor movimiento a movimiento desde la tabla visual interactiva.
* **HECHO VERIFICADO (Jerarquía de Categorías):**
  * En `ExtractosApp.jsx:L16-L24`, se declara una estructura jerárquica estática para clasificar el gasto contable y tributario:
    ```javascript
    const SUBCATEGORIAS = {
      'Insumos':   ['Alimentos', 'Bebidas', 'Embalaje / Packaging', 'Limpieza'],
      'Personal':  ['Nóminas', 'Adelantos', 'Seguros Sociales'],
      ...
    };
    ```
  * Esta jerarquía está fijada al código (Hardcoded Tokens), impidiendo que clientes SaaS de terceros en España o contables especializados definan cuentas o partidas personalizadas de acuerdo al plan general contable aplicable a su negocio.
