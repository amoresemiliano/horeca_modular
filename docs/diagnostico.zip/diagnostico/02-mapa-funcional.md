# 02 - Mapa Funcional del Ecosistema

## 1. Criterio Funcional Estricto y Justificación de Reemplazo

El presente documento sustituye a la versión preliminar de `02-mapa-funcional.md`.
**Justificación del Reemplazo:** En la versión anterior se catalogaron como funcionales o parcialmente funcionales diversos módulos que dependían de simulaciones, estados en memoria o del almacenamiento web del navegador (`localStorage`). Siguiendo la normativa correctora estricta de la Metodología Vegen Digital, se declara categóricamente que:
> **Un módulo basado únicamente en `localStorage`, interfaces renderizadas o formularios simulados NO debe considerarse funcional a nivel empresarial ni multiusuario.**

Para ser declarado **FUNCIONAL**, un módulo debe demostrar de forma inequívoca en su código: entrada de usuario validada, lógica de negocio, persistencia remota robusta, recuperación ante fallos, control de errores y autorización de seguridad firme (sin mocks ni bypass en el camino crítico).

---

## 2. Matriz de Estado de Implementación Real (Criterio Estricto)

Aplicando las clasificaciones normativas de la auditoría sobre el repositorio `el_criollo_modular` y sistemas operacionales asociados, se establece la siguiente tabla de verdad técnica:

| Módulo / Capacidad | Componente / Sistema | Clasificación Estricta | Evidencia en Código y Comprobación de Persistencia | Compatibilidad Multi-Tenant (SaaS) |
| :--- | :--- | :--- | :--- | :--- |
| **1. Extractos y Bancos** | `src/modules/extractos/ExtractosApp.jsx` | 🟢 **FUNCIONAL** | Persistencia real en Supabase (tabla `extractos` en `ExtractosApp.jsx:L87-L91`). Contiene flujo offline de seguridad en `localStorage`. Presenta vulnerabilidad lógica en deduplicación ingenua y falta de parser binario `.xls`. | **Nula:** No envía `tenant_id` en insert ni select, compartiendo datos globales. |
| **2. Control Horario y Fichajes** | `src/modules/horarios/HorariosApp.jsx` | 🟢 **FUNCIONAL** | Lectura y escritura confirmada contra tablas `fichajes`, `incidencias` y `empleados` de Supabase. Cumplimiento de lógica de negocio y cálculo de pausas operativas. | **Nula:** Consultas libres sin políticas RLS de inquilino. |
| **3. Producción de Cocina** | `src/modules/produccion/ProduccionApp.jsx` | 🟢 **FUNCIONAL** | Registro y persistencia de lotes diarios y mermas en tabla `produccion_registros` de Supabase (`ProduccionApp.jsx:L76`). | **Nula:** Sin aislamiento ni filtrado por empresa en base de datos. |
| **4. Compras y Pedidos (Legacy)** | Repositorio `EC_pedidos` (`pedidos/app.js`) | 🟢 **FUNCIONAL** *(Heredado)* | Sistema completo operativo y en producción sobre servidor MySQL (`orders.php`, `products.php`). Generación automática de enlaces WhatsApp y gestión de historial real. | **Nula:** Base de datos monodespacho y roles sin JWT ni RLS. |
| **5. Pedidos (Módulo SPA)** | `src/modules/pedidos/PedidosApp.jsx` | 🟡 **MOCK / SOLO FRONTEND** | Interfaz maquetada en React con listas fijas y estados simulados con `useState` (`PedidosApp.jsx:L8-L12`). No se conecta al backend PHP ni a Supabase. | **Nula:** Interfaz gráfica sin capa de datos activa. |
| **6. Inventario y Almacén** | `src/modules/inventario/store/store.jsx` | 🟡 **SOLO FRONTEND (LocalStorage)** | Motor de reducers sofisticado en cliente pero **100% cautivo en `localStorage`** (`store.jsx:L80-L92`). Sin persistencia remota en Supabase ni sincronización entre terminales. | **Nula (Crítica):** Imbricado exclusivamente en la memoria local del navegador web del dispositivo local. |
| **7. Escandallos (Recetas)** | `src/modules/escandallos/EscandallosApp.jsx` | 🟡 **MOCK / SOLO FRONTEND** | Interfaz visual interactiva con cálculos de Food Cost para "Guacamole" hardcodeados en código. Sin persistencia en servidor. | **Nula:** Inexistencia de tablas de recetas ni composición en SQL. |
| **8. Ventas (Carga TPV)** | `src/modules/ventas/VentasApp.jsx` | 🟠 **PARCIAL / SOLO FRONTEND** | Analizador de CSV del TPV mediante `Papa.parse`. Renderiza tickets en memoria temporal pero no almacena ni sincroniza el histórico en base de datos. | **Nula:** Datos volátiles destruidos tras recargar la pestaña o cambiar de sesión. |
| **9. KPIs & BI** | `src/modules/kpis/KpisApp.jsx` | 🟡 **MOCK / SOLO FRONTEND** | Pantalla con 4 cargadores estáticos de CSV y componentes con notas de desarrollador *"En desarrollo (Chart.js)"*. Sin backend ni agregación automática. | **Nula:** Requiere reprocesamiento manual y aislado en cada sesión local. |
| **10. Predicción & IA** | `src/modules/prediccion/PrediccionApp.jsx` | 🟡 **MOCK / SOLO FRONTEND** | Interfaz prototipo para carga dual de CSV de ventas e inventario para emisión teórica de sugerencias de compra sin motor IA ni SQL remoto conectado. | **Nula:** Lógica y persistencia proyectiva pendientes de desarrollo. |
| **11. Configuración de Empresa** | `Navbar.jsx` / `Configuracion.jsx` | 🟠 **PARCIAL (LocalStorage)** | Selector de empresas y restaurantes cuya selección es puramente estética y gestiona permisos locales cifrados en `localStorage('vdc_permisos')` (`Configuracion.jsx:L5, L17`). | **Nula:** El cambio de restaurante en pantalla no interrumpe ni altera las consultas SQL a Supabase. |
| **12. Gestión de Usuarios** | `HorariosApp.jsx` / `store.jsx` | 🔴 **DUPLICADO / PARCIAL** | Cohabitan 2 sistemas sin sincronizar: usuarios reales de personal en tabla `empleados` de Supabase y lista local en memoria/localStorage en módulo Inventario. | **Nula:** Sin unificación ni correspondencia obligatoria con identidades JWT. |
| **13. Recepción de Mercancía** | Ausente en `el_criollo_modular/src/modules/` | 🔴 **NO IMPLEMENTADO** | No se detecta flujo de validación entre un pedido recibido del proveedor y su correspondiente inyección automática en el inventario de almacén. | N/A (Pendiente de arquitectura). |

---

## 3. Análisis de Flujos Operativos vs Realidad Auditada

* **HECHO VERIFICADO:** Existen dos flujos de datos firmes y reales en el ecosistema actual:
  1. El ciclo bancario: `Descarga CSV → PapaParse en ImportModal.jsx → Filtrado memoria → Insert Supabase (tabla extractos) → Tablas de Consolidación e Impuestos`.
  2. El ciclo de compras real (en `EC_pedidos`): `Selección en TomSelect → Guardado de proveedor → Apertura ventana wa.me (WhatsApp) → Registro POST MySQL (orders.php)`.
* **INFERENCIA:** Los pilares operativos (Almacén, Recetas y Compras dentro de la SPA) operan en un estado de **aislamiento modular no integrado**, violando la "Regla de Oro" de continuidad operacional: una venta del TPV no descuenta ingredientes en almacén ni genera avisos de reposición automáticos hacia el sistema de compras.
