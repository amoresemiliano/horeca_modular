# 11 - Estrategia de Consolidación Arquitectónica

## 1. Principios Directores de la Metodología Vegen Digital SL

La superación de los cuellos de botella auditados en este diagnóstico requiere el despliegue de una hoja de ruta arquitectónica disciplinada que aplique y respete rigurosamente los mandatos doctrinario-técnicos estipulados por la **Metodología Vegen Digital**:
1. **Regla de Oro de Continuidad Operacional:** Ninguna modificación del sistema o migración de servidor debe comprometer o paralizar jamás el curso habitual del servicio HORECA en activo o las rutinas contables cotidianas en Taquería El Criollo y restaurantes afiliados.
2. **Aislamiento Modular sin Acoplamiento Cautivo:** Los módulos de negocio (Extractos, Horarios, Inventario, Pedidos, Recetas) no se invadirán ni sobreescribirán en memoria sus respectivas estructuras, pero se acoplarán canónicamente sobre una **Única Fuente de Verdad (SSoT)** central en la nube administrada en el servidor por interfaces relacionales verificables (APIs o tablas SQL tipificadas con rigor de esquemas).

---

## 2. Hoja de Ruta Modular Hada la Consolidación (De Híbrida a SaaS)

El plan de ingeniería correctivo transforma gradualmente el ecosistema descentralizado del presente hacia una plataforma unificada moderna del lado del servidor preparada para una comercialización segura en régimen de suscripción en España (SaaS Multi-Tenant):

```mermaid
graph TD
    subgraph "Fase Actual: Ecosistema Fragmentado (Híbrido)"
        F1_SPA["SPA el_criollo_modular<br>(Sin RLS en Supabase)"]
        F1_LS["Inventario Cautivo<br>(100% localStorage)"]
        F1_PHP["Sistema Pedidos Legacy<br>(PHP / MySQL BlueHost)"]
        F1_NODE["Servidor Last_API TPV<br>(Webhooks Abiertos)"]
    end

    subgraph "Paso 1: Blindaje, Normalización y Limpieza de Deuda"
        P1_SEC["Saneamiento de Secretos<br>• Purga de .env y passwords en Git<br>• Implementación JWT Firebase ➔ Supabase<br>• Cierre de webhooks con firma HMAC"]
        P1_PARSER["Parser Universal Bancario<br>• Adaptadores binarios (.xls / .xlsx)<br>• Normalización semántica de contrapartes<br>• Algoritmo de hash SHA-256 no ingenuo"]
    end

    subgraph "Paso 2: Centralización Relacional (Supabase SSoT)"
        P2_MIGRA["Unificación del Modelo de Datos<br>• Retirada de BDs heredadas en PHP/MySQL<br>• Migración del Inventario a Supabase<br>• Re-implementación flow WhatsApp en SPA"]
    end

    subgraph "Paso 3: Transformación a SaaS Multi-Tenant"
        P3_SAAS["Aislamiento Corporativo Total<br>• Inyección de columna tenant_id en DDL<br>• Políticas RLS en todas las tablas<br>• Arnés de pruebas automatizadas (Vitest)"]
    end

    F1_SPA --> P1_SEC
    F1_LS --> P2_MIGRA
    F1_PHP --> P2_MIGRA
    F1_NODE --> P1_SEC
    P1_SEC --> P2_MIGRA
    P1_PARSER --> P2_MIGRA
    P2_MIGRA --> P3_SAAS
```

---

## 3. Especificación de Intervenciones Estratégicas por Área

### 3.1. Saneamiento de Seguridad y Sincronización de Autenticación
* **Inmediato (Segunda Fase - Fase 1 de Remediación):** Rotar de inmediato todas las contraseñas de las bases de datos en los servidores web de cPanel (BlueHost) y de `last_API`. Reescribir el historial y retirar del repositorio Git los archivos sensibles (`db_connect.php`, `.env`).
* **Sincronización Token JWT:** Habilitar un servicio en Supabase Auth o un conector Edge Function para validar de manera unívoca el token firmado de Google Auth aportado por Firebase antes de cursar transacciones de base de datos.
* **Erradicar Permisos en Navegador:** Retirar del código de `Configuracion.jsx:L5` las llamadas que delegan la lectura del rol del usuario a variables mutables en el almacenamiento del navegador (`localStorage`), reemplazándolas por consultas blindadas con firmado remoto sobre tablas de empleados con control estricto en servidor.

### 3.2. Adaptador Universal de Ingesta Bancaria (Extractos)
* **Soporte Nativo de Archivos Binarios Excel:** Modificar el analizador en `ImportModal.jsx` incorporando librerías especializadas en tratamiento y lectura binaria en el cliente (como `xlsx` o `exceljs`), facultando al operador para importar de forma indistinta y sin fallos tanto ficheros CSV puros del BBVA y Sabadell como archivos en hojas binarias originales del banco (`.xls` y `.xlsx`).
* **Robustecimiento del Deduplicador:** Sustituir la comprobación temporal ingenua por un discriminante criptográfico (Hash SHA-256) que calcule una huella dactilar indeleble en base de datos al unir la referencia bancaria única, cuenta originaria, importe exacto, saldo bancario subsiguiente y orden de ocurrencia incremental a lo largo de la jornada laboral.

### 3.3. Unificación Operacional en Supabase (Fin del Legado MySQL)
* **Retirada Progresiva de Servidores Monolíticos:** El sistema operativo de compras heredado (`EC_pedidos` / `pedidos/app.js`) será absorbido por completo dentro de la SPA en el componente modular `PedidosApp.jsx`. Se creará un conjunto de tablas relacionales en Supabase (`proveedores`, `catalogo`, `ordenes_compra`, `orden_lineas`) con sus correspondientes claves foráneas explícitas (Foreign Keys), desmantelando sin pérdida operativa los scripts inseguros en PHP sobre el cPanel del proveedor de hosting externo BlueHost.
* **Erradicación de "Islas de Datos" en Inventario:** Reingenierizar los reducers del gestor `usePersistedState` para cesar la dependencia crítica sobre `window.localStorage` en el almacén, orientando toda transacción logística y mermas del local directamente contra las entidades relacionales hospedadas en el esquema en nube de Supabase.

### 3.4. Blindaje Definitivo y Preparación SaaS Multi-Tenant
* **Esquema Aislado (Row Level Security - RLS):** Transformar la plataforma desde un sistema monodespacho y libre hacia una pasarela multiempresa escalable agregando inexorablemente la columna llave `tenant_id (UUID NOT NULL)` sobre absolutamente todas las tablas transaccionales del motor de Supabase.
* **Impartir Políticas Políticas RLS en PostgreSQL:** Activar y promulgar sentencias directas en la base de datos para restringir por fuerza de servidor todas las operaciones CRUD (Lecturas y Escrituras SQL):
  ```sql
  ALTER TABLE extractos ENABLE ROW LEVEL SECURITY;
  CREATE POLICY tenant_isolation_policy ON extractos
      USING (tenant_id = auth.jwt() ->> 'tenant_id');
  ```
* **Impartir Arnés de Testeo Automatizado:** Como salvaguarda de calidad y requisito para prevenir la introducción de errores silenciosos ("Regression Testing"), incorporar la librería ligera **Vitest** en el entorno Vite de `el_criollo_modular` y desarrollar de forma preceptiva casos de prueba unitaria verificados para cada analizador de cobros bancarios, cálculo fiscal y deduplicación en curso.
