# 10 - Fuentes de Verdad y Mapa de Redundancias

## 1. Contexto del Conflicto Referencial en el Ecosistema

Uno de los impedimentos más profundos y costosos para el correcto funcionamiento operativo y el eventual escalado del software empresarial de Taquería El Criollo hacia un servicio Multi-Tenant es la multiplicidad de repositorios desconectados que reclaman la titularidad de los mismos datos de negocio.
La auditoría de este diagnóstico ha delimitado las colisiones referenciales en torno a las tres principales áreas informativas del sistema: **Identidad de Usuarios**, **Catálogo y Existencias**, y **Registros Contables**.

---

## 2. Mapa de Colisiones por Dominio del Dato

El siguiente esquema ilustra la dispersión y falta de supremacía autoritaria de un motor único sobre cada entidad del restaurante:

```mermaid
graph LR
    subgraph "Identidad & Usuarios (5 Fuentes)"
        AUTH_FB["Firebase Auth<br>(Google UID)"]
        AUTH_SQL1[("MySQL Pedidos<br>(tabla users / bcrypt)")]
        AUTH_SQL2[("MySQL Inventario<br>(tabla usuarios)")]
        AUTH_SUPA[("Supabase DB<br>(tabla empleados)")]
        AUTH_LS[("localStorage<br>loggedUser / vdc_permisos")]
    end

    subgraph "Inventario & Productos (4 Fuentes)"
        PROD_LS[("localStorage<br>criollo_productos")]
        PROD_SQL1[("MySQL Inventario<br>tabla productos")]
        PROD_SQL2[("MySQL Pedidos<br>tabla products")]
        PROD_SQL3[("MySQL Last_API<br>tabla ingredients")]
    end

    subgraph "Transacciones & Salarios (3 Fuentes)"
        TX_SUPA[("Supabase DB<br>tabla extractos / fichajes")]
        TX_PED[("MySQL Pedidos<br>tabla orders")]
        TX_LAST[("MySQL Last_API<br>tabla transactions / sales")]
    end

    %% Colisión central
    CONF[("🚨 COLISIÓN REFERENCIAL:<br>Sin Sincronización ni FKs Compartidas")]
    
    AUTH_FB --> CONF
    AUTH_SQL1 --> CONF
    AUTH_LS --> CONF
    PROD_LS --> CONF
    PROD_SQL1 --> CONF
    PROD_SQL2 --> CONF
    TX_SUPA --> CONF
    TX_PED --> CONF
```

---

## 3. Detalle Crítico de Redundancias y Falta de Consistencia

### 3.1. Gestión de Usuarios y Personal
* **HECHO VERIFICADO:** La lista oficial de trabajadores y permisos de gestión está fragmentada en cinco repositorios incompatibles y aislados entre sí:
  1. En `el_criollo_modular` (`Login.jsx`), el usuario se autentica de forma moderna cifrando un token UID con Google en **Firebase Auth**.
  2. Al navegar al módulo de control laboral (`HorariosApp.jsx`), la lista oficial de personal se extrae de la tabla independiente `empleados` administrada sobre **Supabase**, desprovista del identificador de Firebase.
  3. En la pestaña de configuración del restaurante (`Configuracion.jsx`), los permisos sobre corporaciones y tiendas no son leídos de base de datos, sino tomados sin verificar desde **`localStorage('vdc_permisos')`** en el navegador del operador.
  4. Para que un jefe de almacén acceda a encargar insumos al proveedor en la herramienta legacy de compras (`EC_pedidos`), su identidad debe haber sido precargada con usuario y contraseña manual por un script PHP hacia una tabla `users` albergada en el motor **MySQL del cPanel de BlueHost**.
  5. En paralelo, en los volcados heredados de inventarios (`athcomar_inventario_el_criollo.sql`), sobrevive una quinta tabla MySQL redundante (`usuarios`) conteniendo correos, contraseñas hash y fotos de avatares del personal del establecimiento.
* **INFERENCIA:** Si un trabajador causa baja o abandona la empresa, el gerente está forzado a recordar revocar el acceso del ex-empleado manualmente y uno por uno a lo largo de las 5 plataformas, exponiéndose a un riesgo inadmisible de acceso no autorizado y sabotaje operativo por descargas residuales.

### 3.2. Catálogo Gastrónimo, Productos y Almacén
* **HECHO VERIFICADO:** El catálogo de mercancías y consumos tampoco posee un hogar canónico unificado:
  1. En la SPA principal, el módulo `Inventario` confía su lista al almacenamiento en el navegador **`localStorage('criollo_productos')`** (`store.jsx:L104`).
  2. En el servidor TPV (`last_API`), el listado de insumos y costos del menú es custodiado de forma relacional dentro de la tabla **`ingredients`** del motor MySQL correspondiente.
  3. En la herramienta de órdenes por WhatsApp (`EC_pedidos`), la colección de carnes, bebidas y proveedores radica en las tablas **`products`** y **`providers`** del servidor MySQL de compras (`comprasWS`).
* **INFERENCIA:** Una alteración en el coste unitario o nombre del producto "Pollo" o "Guacamole" practicada por el encargado de compras jamás se refleja con exactitud en el balance del almacén ni en los márgenes de beneficio del módulo contable y de recetas.

---

## 4. Plan de Remediación y Supremacía Canónica

Para erradicar de forma definitiva este caótico mapa de redundancias durante la fase inminente de consolidación y reestructuración, la Metodología Vegen Digital impone someter toda entidad del software al cumplimiento indisputable de una **Única Fuente de Verdad Canónica en la Nube (Single Source of Truth - SSoT)** de acuerdo con las siguientes pautas directivas de arquitectura:

| Dominio del Dato | Fuente de Verdad Canónica Destino | Acción Inexorable de Remediación |
| :--- | :--- | :--- |
| **Identidad & Autenticación** | **Firebase / Supabase Auth (JWT)** | Sincronizar por disparador (Trigger o Edge Function) el identificador criptográfico (`uid`) del proveedor hacia el esquema de empleados. Erradicar y prohibir tablas de contraseña en texto o bcrypt sobre MySQL. Eliminar uso de `localStorage` para almacenamiento o decisión con respecto a roles o identidades. |
| **Productos & Proveedores** | **Supabase DB (Tablas Relacionales con `tenant_id`)** | Refactorizar el sistema heredado de compras (`EC_pedidos`), eliminando el servicio en PHP de BlueHost y apuntando el motor en JavaScript para consultar y enriquecer el mismo catálogo contable relacional que consulta el módulo modular de inventarios. |
| **Contabilidad, Ventas y Bancos** | **Supabase DB (Esquema Financiero y TPV)** | Retirar progresivamente los repositorios intermedios o desconectados en MySQL (`last_API` y `comprasWS`), forzando a todas las interfaces operativas y webhooks del restaurante a canalizar sus lecturas y escrituras hacia una base de datos centralizada de tipo PostgreSQL blindada mediante políticas RLS. |
