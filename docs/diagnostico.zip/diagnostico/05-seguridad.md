# 05 - Auditoría de Seguridad y Gestión de Identidad

## 1. Metodología de Inspección y Nota sobre Datos Sensibles

De conformidad con las políticas de seguridad del diagnóstico, se ha practicado un análisis estático de vulnerabilidades sobre los repositorios autorizados en el espacio de trabajo sin ejecutar probadores de penetración, secuencias SQL inyectables, ni peticiones de red agresivas.
> **NOTA DE SEGURIDAD:** Todas las credenciales de acceso, contraseñas de bases de datos y tokens captados durante la auditoría han sido anonimizados en este informe mediante la etiqueta `[REDACTED]`.

---

## 2. Vulnerabilidades Críticas de Exposición de Credenciales (Hardcoded Secrets)

Se han identificado dos brechas críticas de seguridad en la gestión de configuración y control de versiones que exponen la infraestructura de datos del usuario:

1. **Credenciales MySQL en Repositorio de Pedidos (HECHO VERIFICADO):**
   * En `pedidos/backend/db_connect.php:L12-L14`, residen de forma permanente e inalterada las variables en texto plano de producción:
     ```php
     $user = "athcomar_comprasWS_user";
     $pass = "[REDACTED_PASSWORD_MYSQL]";
     $db   = "athcomar_comprasWS";
     ```
   * **Riesgo:** Al estar versionado en el historial público o compartido del repositorio Git, cualquier colaborador u observador que clone `orden_compra_WS` obtiene acceso irrestricto en lectura y escritura a la base de datos de compras del restaurante.

2. **Fichero `.env` Versionado en Backend Last.app (HECHO VERIFICADO):**
   * En `last_API/backend/.env:L4-L6`, se constata la presencia indebida del archivo de entorno en el índice de Git, conteniendo los siguientes parámetros de conexión:
     ```env
     DB_USER=athcomar_vegen_Last_API_user
     DB_PASS=[REDACTED_PASSWORD_LAST_API]
     DB_NAME=athcomar_vegen_Last_API
     ```
   * **Riesgo:** El archivo `.env` ha omitido o saltado la protección del archivo `.gitignore`, exponiendo los privilegios administrativos sobre las tablas contables y de personal operadas en MySQL.

---

## 3. Desconexión Arquitectónica: Firebase Auth vs Supabase DB

* **HECHO VERIFICADO (Autenticación sin Autorización Remota):**
  * El login del usuario se efectúa y valida en el proveedor **Firebase Authentication** usando `signInWithPopup` y una cuenta de Google (`el_criollo_modular/src/components/Login.jsx:L13`).
  * Sin embargo, las transacciones operativas de datos (CRUD) en los módulos activos (Extractos, Horarios, Producción) se procesan directamente contra **Supabase PostgreSQL** utilizando el cliente `@supabase/supabase-js` (`src/lib/supabase.js:L6`).
* **INFERENCIA CRÍTICA:** Al no existir un puente de intercambio de tokens (como un JWT firmado y verificado mutuamente entre las claves públicas de Firebase y Supabase, o una función Edge intermediario), **Supabase desconoce por completo la identidad criptográfica del operador de Firebase**.
* **HECHO VERIFICADO:** Las consultas se autentican de forma anónima con la variable `VITE_SUPABASE_ANON_KEY`, dejando sin efecto el motor de políticas de seguridad a nivel de fila (Row Level Security - RLS). Un atacante que extraiga la clave pública del bundle JS del navegador puede interceptar o ejecutar comandos `supabase.from('extractos').select('*')` desprotegidos.

---

## 4. Manipulación del Control de Acceso y Roles en Cliente (Client-Side Authz)

La autorización en la totalidad del ecosistema presenta un fallo estructural grave al subordinar la comprobación de privilegios a variables mutables en el navegador:

### 4.1. Sistema Moderno `el_criollo_modular`
* **HECHO VERIFICADO:** En `src/modules/configuracion/Configuracion.jsx:L5`, el control de acceso global para la gestión multi-empresa se recupera explícitamente desde el almacenamiento web sin validación ni firma de servidor:
  ```javascript
  const [permisosGlobales, setPermisosGlobales] = useState(() => JSON.parse(localStorage.getItem('vdc_permisos')) || {});
  ```
* **Riesgo:** Cualquier empleado puede abrir la consola de herramientas de desarrollo del navegador de Google Chrome (DevTools) e inyectar permisos modificando el JSON en `vdc_permisos`, logrando que la interfaz renderice pantallas reservadas para cargos superiores.

### 4.2. Sistema de Compras en Producción `EC_pedidos`
* **HECHO VERIFICADO:** En `pedidos/app.js:L86`, tras un login inicial en PHP, el estado de sesión y el rol se confían sin protección al `localStorage`:
  ```javascript
  localStorage.setItem('loggedUser', JSON.stringify({ username: res.user.username, role: res.user.role, name: res.user.name, id: res.user.id }));
  ```
* **HECHO VERIFICADO (Bypass de Servidor en PHP):** En `pedidos/backend/orders.php:L9-L10`, el script PHP filtra el historial de compras consultando ciegamente un parámetro de consulta inseguro entregado por la URL:
  ```php
  $role = isset($_GET['role']) ? $_GET['role'] : 'user';
  ```
* **Riesgo Crítico:** No se valida ninguna sesión del lado del servidor. Un atacante anónimo con conocimientos básicos puede consultar la dirección pública `https://vegendigital.com/sistemas/comprasWS/backend/orders.php?role=admin` y descargar el historial contable al completo de la empresa sin haber iniciado sesión en el sistema.

---

## 5. Auditoría de Endpoints API y Webhooks Abiertos

1. **Webhook sin Autenticación en `last_API` (HECHO VERIFICADO):**
   * En `last_API/backend/src/server.js:L324-L327`, la ruta de captura de transacciones del TPV Last.app se define en los siguientes términos:
     ```javascript
     app.post('/webhook/lastapp', (req, res) => {
       const newTicket = req.body;
       io.emit('ticket_updated', newTicket);
       res.status(200).send('OK');
     });
     ```
   * **Riesgo:** El puerto 3001 del servidor no comprueba cabeceras de autorización HTTP, firmas HMAC ni tokens secretos provenientes de Last.app. Un actor malicioso puede emitir una racha de peticiones POST fabricadas falsamente e inyectar tickets fantasma en los paneles de cocina de los clientes WebSocket sin control alguno.

2. **Análisis de Inyecciones SQL (SQLi):**
   * **HECHO VERIFICADO:** La capa moderna no utiliza sentencias SQL crud, confiando en las consultas parametrizadas por defecto del ORM `@supabase/supabase-js` y de `mysql2/promise` (`server.js:L130`, usando `?` como placeholders), lo que mitiga el riesgo de inyección SQL convencional en los nuevos conectores. No obstante, las consultas heredadas en PHP que concatenan variables y confían en roles pasados por URL exponen la superficie de ataque.

---

## 6. Diferenciación de Riesgos por Escenario Operativo

* **Escenario 1: Uso Interno Inmediato (Taquería El Criollo - Propia):**
  * **Nivel de Riesgo:** **ALTO**. Aunque el personal del restaurante suele comportarse de buena fe, la exposición de archivos `.env` y de credenciales en Git pone a merced de robo o secuestro por piratas informáticos externos todas las bases de datos en BlueHost. Se exige saneación de variables remesas en bruto a la mayor brevedad.
* **Escenario 2: Comercialización SaaS Multi-Tenant (España):**
  * **Nivel de Riesgo:** **INASUMIBLE / BLOQUEANTE**. Es ilegal y operativamente inviable ofrecer a terceros una plataforma que permita acceder mediante la consola DevTools o llamadas con la clave anónima del frontend a las cuentas bancarias, nóminas de personal y compras de empresas o restaurantes de la competencia contratados en el mismo software.
