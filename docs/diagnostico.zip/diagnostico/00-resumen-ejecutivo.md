# 00 - Resumen Ejecutivo

## 1. Contexto y Objetivos del Diagnóstico

El presente documento constituye el Resumen Ejecutivo de la **Fase 0: Diagnóstico Técnico y Funcional Integral** del ecosistema de software de **Taquería El Criollo**, operado en el marco de la **Metodología Vegen Digital SL**.
El propósito principal de este informe es determinar la viabilidad operativa actual del sistema como solución HORECA inmediata y proyectar su evolución técnica hacia una plataforma **SaaS Multi-Tenant** comercializable en España.

## 2. Hallazgos Críticos y Síntesis de Riesgos

La auditoría estática, basada exclusivamente en evidencias verificables del código fuente y volcados de datos autorizados, revela un ecosistema en transición desde sistemas PHP/MySQL heredados hacia una arquitectura moderna SPA en React 19 / Vite con Backend as a Service (Supabase y Firebase). Sin embargo, se identifican hallazgos críticos que comprometen la seguridad, la integridad de los datos y la preparación multi-empresa:

1. **Riesgo Crítico de Seguridad y Roles en Cliente (HECHO VERIFICADO):**
   * Tanto en la aplicación modular moderna (`el_criollo_modular/src/modules/configuracion/Configuracion.jsx:L5-L17`) como en el sistema de pedidos en producción (`pedidos/app.js:L86-L118`), la autorización y los roles (ej. `admin` vs `user`) residen de forma alterable en el `localStorage` del navegador.
   * Un usuario puede modificar su rol desde la consola del navegador y adquirir privilegios visuales de administrador.

2. **Desconexión entre Autenticación y Base de Datos (HECHO VERIFICADO):**
   * En `el_criollo_modular/src/components/Login.jsx:L13`, la autenticación se gestiona mediante Google Auth en **Firebase**. Sin embargo, la persistencia se realiza contra **Supabase** (`el_criollo_modular/src/lib/supabase.js:L6`) empleando una clave pública (`anon_key`) sin validación de token JWT cifrado entre servicios, dejando la base de datos desprovista de autenticación a nivel de servidor.

3. **Exposición de Credenciales en Repositorios (HECHO VERIFICADO):**
   * Se han detectado credenciales de base de datos MySQL en texto plano dentro de ficheros versionados tanto en el sistema legacy (`pedidos/backend/db_connect.php:L12-L14`) como en el backend de integración TPV (`last_API/backend/.env:L4-L6`). Toda información sensible en los informes ha sido redactada.

4. **Incompatibilidad de Formatos Bancarios en Extractos (HECHO VERIFICADO):**
   * Aunque el módulo `Extractos` es el más avanzado computacionalmente, su analizador de archivos (`el_criollo_modular/src/modules/extractos/ImportModal.jsx:L230`) únicamente soporta ficheros de texto `.csv` a través de la librería `PapaParse`. No obstante, las muestras bancarias reales disponibles (`input-samples/extractos/`) son ficheros binarios Excel nativos (`.xls` y `.xlsx`), lo que generará fallos de importación inmediatos en producción si no se introducen adaptadores binarios (ej. `xlsx` o `SheetJS`).

5. **Islas de Información y Ausencia de Relaciones (HECHO VERIFICADO):**
   * El almacén principal (`Inventario`) opera sin conexión a la nube, persistiendo el estado exclusivamente en el `localStorage` del navegador (`el_criollo_modular/src/modules/inventario/store/store.jsx:L102-L107`), lo que impide su operación multiusuario.
   * Los volcados SQL inspeccionados (`database-dumps/athcomar_inventario_el_criollo.sql:L71-L81`) carecen de claves foráneas (Foreign Keys) para vincular productos, almacenes y usuarios, confiando en cadenas de texto propensas a errores ortográficos.

## 3. Conclusiones y Viabilidad

* **Corto Plazo (Restaurantes Propios):** La base moderna `el_criollo_modular` posee una interfaz y experiencia de usuario sobresalientes. No obstante, para operar con seguridad en producción, es obligatorio sanear los endpoints heredados, implementar parsers para archivos `.xls/.xlsx` de BBVA y Sabadell, y unificar el almacenamiento de inventario en Supabase.
* **Largo Plazo (SaaS Multi-Tenant):** La compatibilidad actual es **NULA / NO PREPARADA**, debido a la ausencia absoluta de una columna discriminadora de inquilino (`tenant_id`) y de políticas de seguridad a nivel de fila (RLS) en los esquemas evaluados.
