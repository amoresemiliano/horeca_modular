# 13 - Preguntas Abiertas y Riesgos Operativos Estratégicos

## 1. Contexto de Decisión Directiva

El presente informe expone con claridad los dilemas arquitectónicos, riesgos de cumplimiento normativo y determinaciones directivas ineludibles que la gerencia y los líderes de negocio vinculados a **Taquería El Criollo** y la **Metodología Vegen Digital** deberán abordar de manera clara e irrevocable **antes de dar comienzo a las intervenciones masivas de código programadas en la Fase 1**.

---

## 2. Diferenciación Crítica de Riesgos Operativos

La evaluación de riesgos se segmenta en función del estadio temporal y el objetivo del despliegue del software operativo:

### 2.1. Riesgos en el Escenario Inmediato de Operación Interna (Single-Tenant: El Criollo)
* **Peligro Inminente de Rotura de Stock y Contabilidad (ALTO):**
  * Al sustentarse en la actualidad el control logístico de existencias en el almacenamiento efímero en navegador (`localStorage('criollo_movimientos')`), **el borrado incidental del caché o la limpieza de datos por el cocinero en su navegador del dispositivo o tablet ocasionaría la eliminación instantánea, irrevocable y sin copia de respaldo remota de todo el inventario de almacén y su histórico reciente**.
* **Secuestro o Brecha en Bases de Datos en cPanel (MUY ALTO):**
  * Al constatarse contraseñas en bruto en los archivos de repositorios Git remotos o compartidos (`db_connect.php`, `.env`), cualquier intrusión pasiva de un usuario externo facultaría al asaltante a vaciar o envenenar indiscriminadamente las transacciones reales en el servidor MySQL.

### 2.2. Riesgos en el Escenario Futuro de Comercialización SaaS Multi-Tenant (España)
* **Fallo Criptográfico de Aislamiento Cruzado (CRÍTICO - BLOQUEANTE):**
  * El modelo actual de consultas libres (`supabase.from('extractos').select('*')`) autenticadas mediante una clave anónima sin políticas de seguridad a nivel de fila (**RLS**) impediría de forma absoluta comercializar en firme el producto corporativamente. Un error inadvertido de código expondría cuentas bancarias privadas de un restaurante al administrador de otro cliente suscriptor en internet.
* **Incumplimiento de las Regulaciones Contables y Bancarias en España (CRÍTICO):**
  * La comercialización de sistemas informáticos empresariales y HORECA orientados a facturación o gestión bancaria contable en territorio español se haya inexorablemente afecta por las normativas reguladoras contra el software de ocultación contable (Ley Antifraude / Reglamento VeriFactu) así como el estricto respeto del Reglamento General de Protección de Datos (RGPD) en el manejo y almacenamiento de datos sensibles como nóminas y transacciones comerciales tributarias.

---

## 3. Cuestionario de Decisiones Directivas e Interrogantes Abiertos

A fin de despejar de forma definitiva las ambigüedades técnicas detectadas por la auditoría estática y dotar de seguridad procesal al plan de desarrollo y refactoring inminente, se solicitan resoluciones formales respecto a los siguientes interrogantes directivos y operativos:

### 3.1. Gobernanza sobre Históricos de Datos Heredados
1. **¿Qué tratamiento oficial ha de concedirse a las bases de datos heredadas MySQL (`athcomar_comprasWS` y `athcomar_inventario`) una vez concluida exitosamente su transferencia relacional a Supabase?**
   * *Opción Propuesta por Vegen Digital:* Exportación definitiva en archivo de solo lectura cifrado como archivo histórico fiscal de respiro, y posterior apagado indefinido del puerto o servicio MySQL heredado albergado en los alojamientos tradicionales en BlueHost.
2. **En el proceso de migración de catálogos y almacén hacia Supabase, ¿qué sistema preexistente mantendrá la supremacía nominal del catálogo maestro al dirimir discrepancias ortográficas, de unidades de medida o de costos?**
   * *Contexto del Conflicto:* En el sistema de Pedidos conviven ingredientes en kilogramos mientras en Inventarios operan por formato de cajas o botellas sin una tabla intermedia o maestro relacional coordinado.

### 3.2. Límites y Tiempos en la Integración de Terceros
3. **¿Cuál es la política directiva respecto a los costes y límites de consumo de los conectores de mensajería (WhatsApp / Meta Business) al proyectarse en bloque a escala masiva Multi-Tenant?**
   * *Contexto:* El sistema en producción ejecuta hipervínculos dinámicos sin coste al abrir `window.open('wa.me')` desde el dispositivo de cocina. En un entorno SaaS automatizado de gran envergadura o si se exige trazabilidad total de entrega del mensaje sin abrir ventanas externas al navegador, se requerirá suscribir o pagar credenciales comerciales al API oficial de WhatsApp (Cloud API) o Twilio.
4. **¿Se cuenta en la actualidad con acuerdos o convenios técnicos directos con los fabricantes del TPV `Last.app` para garantizar de forma predecible la estabilidad, inmutabilidad y aseguramiento mediante firma criptográfica HMAC del payload en sus webhooks remitidos al servidor en puerto 3001?**

### 3.3. Alcance de Saneamiento Fiscal y Estructura Bancaria
5. **¿Debe restringirse de antemano el diseño relacional del motor de cuentas y cobros de Supabase al estándar estricto del Plan General Contable HORECA aplicable al territorio fiscal y comercial de España, o se requiere dotar al módulo contable y tributario de adaptabilidad cosmopolita desde la primera versión de lanzamiento SaaS para dar soporte futuro a mercados extranjeros hispanopagamos (México, Colombia, Argentina)?**
