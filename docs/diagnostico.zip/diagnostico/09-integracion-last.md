# 09 - Integración Last.app y Motor Analítico de Cocina

## 1. Arquitectura y Rol del Backend Analítico (`last_API`)

El repositorio `last_API` constituye una pieza de software full-stack independiente (operando sobre un servidor Node.js/Express en el puerto 3001 con base de datos MySQL dedicada y un frontend auxiliar) que cumple una doble función crítica dentro de la operación HORECA moderna de Taquería El Criollo:
1. **Pasarela TPV en Tiempo Real:** Escucha eventos automáticos (webhooks) originados desde el terminal de punto de venta físico en el restaurante (TPV Last.app) para transmitir actualizaciones sobre tickets e incidencias operativas mediante conexiones WebSocket a las cocinas y monitores de barra.
2. **Motor Analítico Gastrocultural (Matriz BCG):** Clasifica de manera continua el rendimiento de las recetas y platos del restaurante según la metodología de la Matriz del Boston Consulting Group (BCG) o ingeniería de menú.

---

## 2. Radiografía de Endpoints, Webhooks y Persistencia Real

La inspección del archivo central de servidor `last_API/backend/src/server.js` y de su volcado relacional `athcomar_vegen_Last_API.sql` constata los siguientes flujos de ejecución y modelo de datos:

### 2.1. Seguridad y Exposición en el Puerto de Escucha
* **Autenticación Criptográfica Robusta en Rutas API (HECHO VERIFICADO):**
  * Para las peticiones a endpoints internos como `/api/ingredients`, `/api/products` o `/api/shifts`, el servidor hace respetar en estricto rigor el estándar JWT. La función middleware recupera el token Bearer en cabecera HTTP y lo somete a verificación del servidor de claves de Google (`server.js:L72`):
    ```javascript
    const decodedToken = await admin.auth().verifyIdToken(token);
    ```
  * El usuario queda adecuadamente vinculado al sistema almacenando y emparejando su identificador de Firebase (`uid`) en las columnas de la base de datos (ej. `'yWyEEbBSKCggJFX...'`).
* **Vulnerabilidad Crítica de Seguridad en Webhook de Entrada (HECHO VERIFICADO):**
  * En franca antítesis a la protección de las rutas internas, el endpoint receptor encargado de comunicarse con el TPV en internet remanece absolutamente desprovisto de mecanismos de defensa (`server.js:L324-L327`):
    ```javascript
    app.post('/webhook/lastapp', (req, res) => {
      const newTicket = req.body;
      io.emit('ticket_updated', newTicket);
      res.status(200).send('OK');
    });
    ```
  * **Riesgo Operativo (Inyección sin Persistencia):**
    1. No se realiza ningún tipo de autenticación previa, validación de dirección IP de origen, ni verificación de firma secreta HMAC-SHA por parte del remitente de la petición HTTP.
    2. El servidor simplemente recibe cualquier objeto en el cuerpo del JSON y lo reenvía ciegamente por el canal abierto de WebSocket (`io.emit('ticket_updated')`) a todos los clientes que mantengan una pantalla activa, abriendo una vulnerabilidad idónea para inyección de comandas espurias o sabotaje operativo por ataques masivos de denegación de servicio ligero.
    3. Al emitir directamente al socket y finalizar la llamada con un código `200 OK`, el servidor no registra la comanda en la base de datos ni almacena un archivo de auditoría del evento entrante.

### 2.2. Ingeniería de Menú: Persistencia en la Matriz BCG
* **HECHO VERIFICADO:** En el volcado SQL y en los controladores del servidor se mantiene una tabla dedicada al seguimiento histórico analítico: `product_bcg_history` (`server.js:L185-L210`).
* **HECHO VERIFICADO:** Clasifica de manera persistente las ventas del restaurante situando los productos gastronómicos en las cuatro regiones clásicas del rendimiento comercial:
  * `STAR` (Producto Estrella: alta rentabilidad y alta rotación de venta).
  * `PLOW` / `PLOWHORSE` (Caballo de Batalla o Burro: baja rentabilidad individual pero altísima popularidad de consumo en sala).
  * `PUZZLE` (Producto Enigma: alta rentabilidad individual por margen pero rotación escasa en pedidos).
  * `DOG` (Producto Perro: bajo volumen de ventas y bajo margen de contribución).

---

## 3. Estrategia de Sincronización y Alimentación hacia la Plataforma Maestra

* **INFERENCIA / DIAGNÓSTICO DEL MODELO ACTUAL:**
  * En la actualidad, el ecosistema padece un fallo arquitectónico general: mientras `last_API` calcula y procesa un volumen masivo de datos de ventas en tiempo real, los módulos frontales correspondientes dentro de la nueva SPA maestra (`el_criollo_modular/src/modules/ventas/VentasApp.jsx` y `src/modules/kpis/KpisApp.jsx`) ignoran por completo este backend, obligando al usuario administrativo a descargar periódicamente reportes de ventas en archivos CSV para volver a cargarlos y parsear mediante PapaParse a mano en cada sesión independiente en memoria temporal del navegador.
* **RECOMENDACIÓN TÉCNICA (Eliminación de la Carga CSV):**
  * Para erradicar esta ineficiente isla operacional y avanzar hacia una verdadera solución HORECA cohesionada, la lógica del servidor analítico `last_API` debe ser refactorizada o transpuesta hacia Funciones sin servidor en nube (ej. **Supabase Edge Functions** en Deno o Firebase Cloud Functions) que:
    1. Validen mediante un secreto criptográfico compartido por cabecera HTTP la autenticidad de cada webhook emitido por el sistema TPV de Last.app.
    2. Al recibir y validar una venta real, escriban su asiento contable correlado y sus métricas de consumo con etiqueta de inquilino de empresa (`tenant_id`) directamente dentro del esquema unificado de tablas en PostgreSQL (`ventas_tpv` e `historia_bcg`).
    3. Permitan al frontend maestro consultar en tiempo real las gráficas contables, mermas de almacén e informes estratégicos sin obligar al gerente a importar interminables ficheros manuales al final de la jornada la jornada de trabajo diaria del restaurante.
