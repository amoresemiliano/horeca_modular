# 08 - Módulo de Pedidos: Flujo Operativo y Estrategias de Migración

## 1. Alcance y Dualidad Tecnológica Actual

El análisis técnico del ecosistema revela una profunda dicotomía entre el sistema de compras actualmente en uso operativo en producción y la nueva interfaz proyectada dentro de la plataforma maestra:

* **Sistema de Producción Real (`EC_pedidos` / `pedidos/`):** Desarrollado en JavaScript Vanilla con servidor PHP y base de datos MySQL relacional (`athcomar_comprasWS`). Es una herramienta operativa, comprobada en el día a día del restaurante y adaptada a la comunicación ágil con proveedores del sector HORECA.
* **Módulo SPA Moderno (`el_criollo_modular/src/modules/pedidos/PedidosApp.jsx`):** Es a fecha actual un **Prototipo Visual / Mock** desconectado. Renderiza un listado estático fijado en el estado (`PedidosApp.jsx:L8-L12`) mediante `useState([{ id: 1, proveedor: 'Carnicería Carlos', total: 150.50 }, ...])` y carece de integración web real con bases de datos o pasarelas de mensajería instantánea.

---

## 2. Reconstrucción del Flujo Operativo Real (Evidencia en `EC_pedidos`)

La auditoría del código fuente de `pedidos/app.js` permite trazar de manera indiscutible y milimétrica el ciclo de vida de un pedido de compra en Taquería El Criollo:

```mermaid
sequenceDiagram
    autonumber
    actor Gerente as Gerente / Cocinero
    participant UI as Interfaz Web (app.js + TomSelect)
    participant WA as Pasarelas WhatsApp (wa.me)
    participant API as Backend PHP (orders.php / providers.php)
    participant BD as MySQL (athcomar_comprasWS)

    Gerente->>UI: 1. Selecciona Proveedor en menú TomSelect (L328)
    UI->>BD: Filtra productos del proveedor (provider_ids_array en L284)
    Gerente->>UI: 2. Añade productos al carrito con cantidades y unidades (L145)
    Gerente->>UI: 3. Pulsa botón "Enviar Pedido por WhatsApp" (L183)
    UI->>API: 4a. Verifica y guarda el proveedor si es nuevo (L191 / L253)
    API->>BD: INSERT en tabla providers
    UI->>UI: 4b. Formatea cadena de texto con viñetas y mensaje formal (L193-L195)
    UI->>WA: 5. Abre ventana emergente: window.open('https://wa.me/TELEFONO?text=MENSAJE')
    UI->>API: 6. POST en paralelo a orders.php para registrar orden contable (L199 / L242)
    API->>BD: INSERT en tablas orders y order_items (ref #1234)
```

### 2.1. Componentes Clave del Flujo Auditado
* **Filtrado Avanzado por Múltiples Proveedores (HECHO VERIFICADO):**
  * En `pedidos/app.js:L284-L308`, el código maneja un array complejo (`provider_ids_array`) o una lista separada por comas que permite que un mismo insumo gastroculto o ingrediente esté asignado indistintamente a varios proveedores, cargando las listas desplegables ágiles gracias al motor de búsqueda autocomplementaria de **TomSelect** (`L316-L325`).
* **Automatización del Despacho por WhatsApp (HECHO VERIFICADO):**
  * En `pedidos/app.js:L183-L198`, la función `sendOrder()` construye una cadena de texto formal estructurada:
    ```text
    Buenos días, le envío la orden de compra de El Criollo, ¡muchas gracias!
    • Entrecot de Ternera: 5 kg
    • Pollo Entero: 10 kg
    Quedo a la espera de confirmación. Saludos cordiales.
    ```
  * Inmediatamente gatilla un salto en el navegador: `window.open('https://wa.me/' + phone + '?text=' + encodeURIComponent(fullMsg), '_blank');`.
* **Persistencia Ciega de Historial (HECHO VERIFICADO):**
  * En L242, `saveToHistory` invoca `api.post('orders.php', orderData)`, confiando en la sesión almacenada precariamente en `localStorage` y en números de referencia aleatorios generados en el cliente mediante `Math.floor(1000 + Math.random() * 9000)` (`L245`), violando principios elementales de secuencialidad contable única e irrepetible.

---

## 3. Evaluación de Opciones de Migración y Consolidación Arquitectónica

Ante el mandato ineludible de unificar las herramientas dispersas del restaurante dentro de la plataforma principal en Supabase (`el_criollo_modular`), se presentan y evalúan dos estrategias arquitectónicas enfrentadas:

| Criterio de Análisis | Opción A: Mantenimiento Temporal MySQL vía Adaptador / Puente API | Opción B (RECOMENDADA): Migración Progresiva de Datos a Supabase + Recreación Flow React |
| :--- | :--- | :--- |
| **Descripción Técnica** | Mantener el servidor MySQL actual en BlueHost y refactorizar el módulo `PedidosApp.jsx` de la SPA moderna para realizar peticiones HTTP Fetch al backend `comprasWS/backend/`. | Volcar las tablas `providers`, `products`, `orders` de MySQL hacia nuevas tablas equivalentes y relacionales (con `tenant_id`) en Supabase, y reimplementar la rutina `sendOrder()` y Tom-Select en componentes React puros. |
| **Complejidad Inicial** | **Baja:** La lógica de servidor en PHP ya opera, solo requiere conectar las interfaces en la SPA. | **Media-Alta:** Exige crear modelos de migración DDL y traducir los helpers de autocompleto Tom-Select a selectores dinámicos compatibles con React 19. |
| **Seguridad y Deuda Técnica** | **Pésima:** Perpetúa credenciales en código en BlueHost, endpoints con autenticación insegura en la URL y multiplica puntos de fallo transversales al depender de un servidor externo de terceros. | **Excelente:** Elimina para siempre el servidor PHP monolítico, centraliza los backups de base de datos en un solo motor (Supabase PostgreSQL) y aplica control de acceso firme mediante RLS. |
| **Viabilidad Multi-Tenant SaaS** | **Incompatible (Nula):** El backend PHP carece de aislamiento. Modificar PHP para soportar inquilinos supondría rehacer la aplicación desde el principio. | **Totalmente Preparada:** Al insertar la columna `tenant_id`, la plataforma queda lista para segregar el historial de compras e inventario de múltiples corporaciones. |
| **Decisión Vegen Digital** | **RECHAZADA:** Genera deuda técnica acumulada de alto coste operativo y vulnerabilidades críticas inaceptables. | **APROBADA (Camino Canónico):** Se opta invariablemente por la Opción B como estándar directivo indiscutible de este diagnóstico para la hoja de ruta de implementación. |
